export const designTokens = {
  brand: { name: "Modalia", direction: "premium editorial commerce" },
  radius: { card: 24, hero: 34, pill: 999 },
  spacing: { section: "clamp(4rem, 8vw, 8rem)" },
  typography: { display: "Manrope, Noto Sans Arabic, system-ui, sans-serif", body: "IBM Plex Sans, Noto Sans Arabic, system-ui, sans-serif" },
  motion: { standard: 0.3, reveal: 0.6, cinematic: 1.1 },
} as const;
