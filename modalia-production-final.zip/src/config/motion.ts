export const motion = {
  fast: "duration-150",
  standard: "duration-300",
  slow: "duration-700",
  easing: "ease-[cubic-bezier(.22,1,.36,1)]",
  transition: "transition-all duration-300 ease-[cubic-bezier(.22,1,.36,1)] motion-reduce:transition-none",
  reveal: "motion-safe:animate-[modalia-reveal_.6s_cubic-bezier(.22,1,.36,1)_both]",
  lift: "transition-transform duration-300 ease-out hover:-translate-y-1 motion-reduce:transition-none motion-reduce:hover:transform-none",
} as const;
