-- Align enum values with the operational status model used by seller/admin workflows.
ALTER TYPE public.order_status ADD VALUE IF NOT EXISTS 'preparing';
ALTER TYPE public.order_status ADD VALUE IF NOT EXISTS 'ready_for_shipping';
ALTER TYPE public.order_status ADD VALUE IF NOT EXISTS 'handed_to_courier';
ALTER TYPE public.order_status ADD VALUE IF NOT EXISTS 'in_transit';
ALTER TYPE public.order_status ADD VALUE IF NOT EXISTS 'returned';
ALTER TYPE public.order_status ADD VALUE IF NOT EXISTS 'failed_delivery';

ALTER TYPE public.seller_order_status ADD VALUE IF NOT EXISTS 'preparing';
ALTER TYPE public.seller_order_status ADD VALUE IF NOT EXISTS 'ready_for_shipping';
ALTER TYPE public.seller_order_status ADD VALUE IF NOT EXISTS 'handed_to_courier';
ALTER TYPE public.seller_order_status ADD VALUE IF NOT EXISTS 'in_transit';
ALTER TYPE public.seller_order_status ADD VALUE IF NOT EXISTS 'delivered';
ALTER TYPE public.seller_order_status ADD VALUE IF NOT EXISTS 'returned';
ALTER TYPE public.seller_order_status ADD VALUE IF NOT EXISTS 'failed_delivery';

-- The existing transition function remains the single server-side status mutation path.
